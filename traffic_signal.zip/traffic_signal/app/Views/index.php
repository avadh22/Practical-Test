<!DOCTYPE html>
	<html>
		<head>
			<title>Practical Test</title>
			<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
			<link rel="stylesheet" href="styles.css">
			<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		</head>
		<body>
			<header>
      <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Practical Test</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <s̛pan class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <button class="btn btn-primary">Avadh Chav</button>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <div class="container-fluid">
	    <section class="p-2 mt-3 bg-light border">
	    	<div class="row">
	    		<div class="col-md-3">
	    			<label class="text-center fs-4 text-center"> Signal A </label>
	    			<div class="mt-3 circle-red signal" id="signal_a"></div>
	    			<input type="text" class="form-control mt-3 signal_a" value="2">

	    		</div>
	    		<div class="col-md-3">
	    			<label class="text-center fs-4 text-center">Signal B</label>
	    			<div class="mt-3 circle-red signal" id="signal_b"></div>
	    			<input type="text" class="form-control mt-3 signal_b" value="1">
	    		</div>
	    		<div class="col-md-3">
	    			<label class="text-center fs-4 text-center">Signal C</label>
	    			<div class="mt-3 circle-red signal" id="signal_c"></div>
	    			<input type="text" class="form-control mt-3 signal_c" value="4">
	    		</div>
	    		<div class="col-md-3">
	    			<label class="text-center fs-4 text-center">Signal D</label>
	    			<div class="mt-3 circle-red signal" id="signal_d"></div>
	    			<input type="text" class="form-control mt-3 signal_d" value="3">
	    		</div>
	    	</div>
	    </section>

	    <section class="mt-5 mb-5 p-2 bg-light border">
	    	<div class="mb-3 row">
	  			<div class="mb-3 row">
		    		<label for="inputPassword" class="col-sm-2 col-form-label">Green light intervels</label>
				    <div class="col-sm-6">
				      	<input type="text" class="form-control" id="green-light-intervel" value="3">
				    </div>
	  			</div>
	  		</div>

	  		<div class="mb-3 row">
	  			<div class="mb-3 row">
		    		<label for="inputPassword" class="col-sm-2 col-form-label">Yellow light intervels</label>
				    <div class="col-sm-6">
				      	<input type="text" class="form-control" id="yellow-light-intervel" value="1">
				    </div>
	  			</div>
	  		</div>

	  		<div class="row">
	  			<div class="col-md-6 p-2">
	  				<button type="button" class="btn btn-primary mb-3 col-sm-12 btn-success" id="start">Start</button>	
	  			</div>
	  			<div class="col-md-6 p-2">
	  				<button type="button" class="btn btn-primary mb-3 col-sm-12 btn-danger" id="stop">Stop</button>
	  			</div>
	  		</div>
	    </section>
    </div>

    <footer class="footer">
      <span>
        Email :-  <a href="mailto:avadhjoshi1993@gmail.com">avadhjoshi1993@gmail.com</a>
      </label>
      <ul>
        <span class="nav-item">
        	Mobile Number :-  <a href="tel:9724036716">9724036716</a>
      </label>
      </ul>
    </footer>
		</body>
		<script type="text/javascript">
			var signal;
			var i = 1;
			var status = 1;
			$(document).ready(function(){
            	
            	$("#start").click(function(){
            		status = 1;
            		i = 1; 
            		first();
            	});

            	$("#stop").click(function(){
            		$("#"+signal).css("background-color", "#f00");
            		status = 0;
            		return false;
            	});



            	
            	function first() {
            		if(status == 1){
	            		var signal_a = $(".signal_a").val();
	            		var signal_b = $(".signal_b").val();
	            		var signal_c = $(".signal_c").val();
	            		var signal_d = $(".signal_d").val();
	            		var green_light_intervel = $("#green-light-intervel").val() * 1000;
	            		var yellow_light_intervel = $("#yellow-light-intervel").val() * 1000;
	            		if(signal_a == i){
	            			signal = "signal_a";
	            		}

	            		if(signal_b == i){
	            		    signal = "signal_b";
	            		}
	            		if(signal_c == i){
	            			signal = "signal_c";
	            		}
	            		if(signal_d == i){
	            			signal = "signal_d";
	            		}
	            		console.log(signal);
	            		greenlightintervel(green_light_intervel,yellow_light_intervel);
            		}
            	}
	            

            	function greenlightintervel(intervel,yellow_intervel) {
            		if(status == 1){
	            	    $("#"+signal).css("background-color", "#48BA00");

	            		setTimeout(function(intervel){
		                	yellowlightintervel(yellow_intervel)
		            	}, intervel); 		
		            }
            	}	

            	function yellowlightintervel(intervel) {
            		if(status == 1){
	            		$("#"+signal).css("background-color", "#f7bc0b");
	            		setTimeout(function(intervel,signal){
		                	redlightintervel()
		            	}, intervel); 
		            }
            	}

            	function redlightintervel() {
            		if(status == 1){
	            		i == i++;
	            		if(i == 5){
	            			i = 1;
	            		}
	            		$("#"+signal).css("background-color", "#f00");
	            		first();
	            	}
            	}
            	
        	});
		</script>
	</html>


